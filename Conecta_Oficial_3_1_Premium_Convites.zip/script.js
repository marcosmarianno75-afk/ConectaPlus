const storageKeys = {
  users: "conecta-users",
  session: "conecta-session",
  posts: "conecta-posts",
  notifications: "conecta-notifications",
  groups: "conecta-groups",
  stories: "conecta-stories"
};

const defaultAvatar = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=96&q=80";
const defaultStoryImage = "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=600&q=80";
const authScreen = document.querySelector("#authScreen");
const appScreen = document.querySelector("#appScreen");
const authMessage = document.querySelector("#authMessage");
const authTabs = document.querySelectorAll("[data-auth-tab]");
const loginForm = document.querySelector("#loginForm");
const signupForm = document.querySelector("#signupForm");
const signupAvatar = document.querySelector("#signupAvatar");
const signupAvatarPreview = document.querySelector("#signupAvatarPreview");
const logoutButton = document.querySelector("#logoutButton");
const changePhotoButton = document.querySelector("#changePhotoButton");
const changePhotoInput = document.querySelector("#changePhotoInput");
const notificationButton = document.querySelector("#notificationButton");
const notificationPanel = document.querySelector("#notificationPanel");
const notificationCount = document.querySelector("#notificationCount");
const notificationList = document.querySelector("#notificationList");
const clearNotificationsButton = document.querySelector("#clearNotificationsButton");
const homeButton = document.querySelector("#homeButton");
const groupsButton = document.querySelector("#groupsButton");
const topGroupsButton = document.querySelector("#topGroupsButton");
const sideGroupsButton = document.querySelector("#sideGroupsButton");
const topProfileButton = document.querySelector("#topProfileButton");
const sideProfileButton = document.querySelector("#sideProfileButton");
const openComposer = document.querySelector("#openComposer");
const postDialog = document.querySelector("#postDialog");
const postText = document.querySelector("#postText");
const publishPost = document.querySelector("#publishPost");
const btnPhoto = document.querySelector("#btnPhoto");
const btnLive = document.querySelector("#btnLive");
const btnMood = document.querySelector("#btnMood");
const postMediaInput = document.querySelector("#postMediaInput");
const storyViewer = document.querySelector("#storyViewer");
const closeStoryViewer = document.querySelector("#closeStoryViewer");
const storyViewerAvatar = document.querySelector("#storyViewerAvatar");
const storyViewerAuthor = document.querySelector("#storyViewerAuthor");
const storyViewerTime = document.querySelector("#storyViewerTime");
const storyViewerImage = document.querySelector("#storyViewerImage");
const storyViewerText = document.querySelector("#storyViewerText");
let selectedPostMedia = null;
const storiesContainer = document.querySelector(".stories");
const openStoryDialog = document.querySelector("#openStoryDialog");
const storyDialog = document.querySelector("#storyDialog");
const storyForm = document.querySelector("#storyForm");
const storyImage = document.querySelector("#storyImage");
const storyPreview = document.querySelector("#storyPreview");
const storyText = document.querySelector("#storyText");
const publishStory = document.querySelector("#publishStory");
const feed = document.querySelector(".feed");
const composer = document.querySelector(".composer");
const profileView = document.querySelector("#profileView");
const groupsView = document.querySelector("#groupsView");
const profileEmail = document.querySelector("#profileEmail");
const profileBio = document.querySelector("#profileBio");
const profileAbout = document.querySelector("#profileAbout");
const profilePostsList = document.querySelector("#profilePostsList");
const editBioButton = document.querySelector("#editBioButton");
const bioDialog = document.querySelector("#bioDialog");
const bioText = document.querySelector("#bioText");
const saveBioButton = document.querySelector("#saveBioButton");
const openGroupDialog = document.querySelector("#openGroupDialog");
const groupDialog = document.querySelector("#groupDialog");
const groupForm = document.querySelector("#groupForm");
const groupName = document.querySelector("#groupName");
const groupCategory = document.querySelector("#groupCategory");
const groupDescription = document.querySelector("#groupDescription");
const groupsList = document.querySelector("#groupsList");
const onlineFriendsList = document.querySelector("#onlineFriendsList");
const presenceStatus = document.querySelector("#presenceStatus");
let presenceChannel = null;
let presenceHeartbeat = null;

function readStorage(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) || fallback;
  } catch {
    return fallback;
  }
}

function getUsers() {
  return readStorage(storageKeys.users, []);
}

function saveUsers(users) {
  localStorage.setItem(storageKeys.users, JSON.stringify(users));
}

function getPosts() {
  return readStorage(storageKeys.posts, []);
}

function savePosts(posts) {
  localStorage.setItem(storageKeys.posts, JSON.stringify(posts));
}

function getStories() {
  const oneDay = 24 * 60 * 60 * 1000;

  return readStorage(storageKeys.stories, []).filter((story) => {
    return Date.now() - new Date(story.createdAt).getTime() < oneDay;
  });
}

function saveStories(stories) {
  localStorage.setItem(storageKeys.stories, JSON.stringify(stories));
}

function getGroups() {
  return readStorage(storageKeys.groups, []);
}

function saveGroups(groups) {
  localStorage.setItem(storageKeys.groups, JSON.stringify(groups));
}

function getNotifications() {
  const session = getSession();
  if (!session) return [];

  return readStorage(storageKeys.notifications, []).filter((notification) => {
    return notification.userEmail === session.email || !notification.userEmail;
  });
}

function saveNotifications(notifications) {
  const session = getSession();

  if (!session) {
    localStorage.setItem(storageKeys.notifications, JSON.stringify(notifications));
    return;
  }

  const otherUsersNotifications = readStorage(storageKeys.notifications, []).filter((notification) => {
    return notification.userEmail && notification.userEmail !== session.email;
  });
  const currentUserNotifications = notifications.map((notification) => ({
    ...notification,
    userEmail: notification.userEmail || session.email
  }));

  localStorage.setItem(storageKeys.notifications, JSON.stringify([
    ...otherUsersNotifications,
    ...currentUserNotifications
  ]));
}

function getSession() {
  return readStorage(storageKeys.session, null);
}

function setSession(user) {
  localStorage.setItem(storageKeys.session, JSON.stringify({
    name: user.name,
    email: user.email,
    avatar: user.avatar || defaultAvatar,
    bio: user.bio || ""
  }));
}

function readImageFile(file) {
  return new Promise((resolve, reject) => {
    if (!file) {
      resolve(defaultAvatar);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Nao foi possivel ler a imagem."));
    reader.readAsDataURL(file);
  });
}

function readStoryImageFile(file) {
  return readImageFile(file).then((image) => {
    return image === defaultAvatar ? defaultStoryImage : image;
  });
}

function readMediaFile(file) {
  return new Promise((resolve, reject) => {
    if (!file) {
      resolve(null);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => resolve({
      name: file.name,
      type: file.type,
      dataUrl: reader.result
    });
    reader.onerror = () => reject(new Error("Nao foi possivel ler o arquivo."));
    reader.readAsDataURL(file);
  });
}

function setAuthMessage(message, type = "error") {
  authMessage.textContent = message;
  authMessage.dataset.type = type;
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function showAuthTab(tabName) {
  authTabs.forEach((tab) => {
    tab.classList.toggle("active", tab.dataset.authTab === tabName);
  });

  loginForm.classList.toggle("active", tabName === "login");
  signupForm.classList.toggle("active", tabName === "signup");
  setAuthMessage("");
}

function updateUserInterface(user) {
  const firstName = user.name.split(" ")[0] || user.name;
  const avatar = user.avatar || defaultAvatar;
  const bio = user.bio || "Conte um pouco sobre voce.";

  document.querySelectorAll(".profile-name").forEach((item) => {
    item.textContent = user.name;
  });
  document.querySelectorAll(".user-avatar").forEach((image) => {
    image.src = avatar;
  });

  openComposer.textContent = `No que voce esta pensando, ${firstName}?`;
  postText.placeholder = `No que voce esta pensando, ${firstName}?`;
  profileEmail.textContent = user.email;
  profileBio.textContent = bio;
  profileAbout.textContent = bio;
}

function getPostDateLabel(dateValue) {
  const date = new Date(dateValue);
  return date.toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  });
}

function getStoryTimeLabel(dateValue) {
  const diff = Date.now() - new Date(dateValue).getTime();
  const minutes = Math.max(1, Math.round(diff / 60000));

  if (minutes < 60) return `${minutes} min`;

  return `${Math.round(minutes / 60)} h`;
}

function getRelativeNotificationTime(dateValue) {
  const diff = Date.now() - new Date(dateValue).getTime();
  const minutes = Math.max(1, Math.round(diff / 60000));

  if (minutes < 60) return `${minutes} min`;

  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours} h`;

  return new Date(dateValue).toLocaleDateString("pt-BR");
}

function addNotification(message) {
  const session = getSession();
  if (!session) return;

  const notifications = [{
    id: crypto.randomUUID(),
    userEmail: session.email,
    message,
    createdAt: new Date().toISOString(),
    read: false
  }, ...getNotifications()].slice(0, 20);

  saveNotifications(notifications);
  renderNotifications();
}

function renderNotifications() {
  const notifications = getNotifications();
  const unread = notifications.filter((item) => !item.read).length;

  notificationCount.hidden = unread === 0;
  notificationCount.textContent = unread;
  notificationList.innerHTML = "";

  if (!notifications.length) {
    const empty = document.createElement("p");
    empty.className = "empty-notifications";
    empty.textContent = "Nenhuma notificacao por enquanto.";
    notificationList.appendChild(empty);
    return;
  }

  notifications.forEach((notification) => {
    const item = document.createElement("article");
    item.className = "notification-item";
    item.classList.toggle("unread", !notification.read);
    item.innerHTML = "<span></span><time></time>";
    item.querySelector("span").textContent = notification.message;
    item.querySelector("time").textContent = getRelativeNotificationTime(notification.createdAt);
    notificationList.appendChild(item);
  });
}

function markNotificationsRead() {
  const notifications = getNotifications().map((item) => ({ ...item, read: true }));
  saveNotifications(notifications);
  renderNotifications();
}

function getSupabaseConfig() {
  window.conectaConfig = window.conectaConfig || {
    supabaseUrl: "",
    supabaseAnonKey: ""
  };

  const config = window.conectaConfig || {};

  if (!config.supabaseUrl || !config.supabaseAnonKey || !window.supabase) {
    return null;
  }

  return config;
}

function getPresenceUsers(presenceState) {
  return Object.values(presenceState).flat().reduce((users, presence) => {
    if (!presence.email || users.some((user) => user.email === presence.email)) return users;
    users.push(presence);
    return users;
  }, []);
}

function renderOnlineFriends(users) {
  const currentUser = getSession();
  onlineFriendsList.innerHTML = "";

  if (!users.length && currentUser) {
    users.push({
      name: currentUser.name,
      email: currentUser.email,
      avatar: currentUser.avatar || defaultAvatar,
      localOnly: true
    });
  }

  if (!users.length) {
    const empty = document.createElement("p");
    empty.className = "empty-online-friends";
    empty.textContent = "Nenhum contato online.";
    onlineFriendsList.appendChild(empty);
    return;
  }

  users.forEach((friend) => {
    const item = document.createElement("article");
    item.className = "contact online-friend";
    item.innerHTML = `
      <span class="online"></span>
      <img src="" alt="">
      <span class="online-friend-info"><strong></strong><small></small></span>
    `;

    item.querySelector("img").src = friend.avatar || defaultAvatar;
    item.querySelector("strong").textContent = friend.name || "Usuario";
    item.querySelector("small").textContent = friend.email === currentUser?.email ? "Voce" : "Online";
    onlineFriendsList.appendChild(item);
  });
}

function stopPresence() {
  if (presenceHeartbeat) {
    clearInterval(presenceHeartbeat);
    presenceHeartbeat = null;
  }

  if (presenceChannel) {
    presenceChannel.unsubscribe();
    presenceChannel = null;
  }
}

async function saveCurrentUserOnline(client, user) {
  if (!client || !user?.email) return;

  await client
    .from("online_users")
    .upsert({
      email: user.email,
      name: user.name || "Usuario",
      avatar: user.avatar || defaultAvatar,
      last_seen: new Date().toISOString()
    }, { onConflict: "email" });
}

async function loadOnlineUsers(client) {
  if (!client) return;

  const cutoff = new Date(Date.now() - 90 * 1000).toISOString();
  const { data, error } = await client
    .from("online_users")
    .select("name,email,avatar,last_seen")
    .gte("last_seen", cutoff)
    .order("last_seen", { ascending: false });

  if (error) {
    console.error("Erro ao carregar usuarios online:", error);
    return;
  }

  renderOnlineFriends(data || []);
}

function startPresence(user) {
  stopPresence();

  const config = getSupabaseConfig();
  if (!config || !window.supabase || !user) {
    presenceStatus.textContent = "Local";
    renderOnlineFriends([]);
    return;
  }

  presenceStatus.textContent = "Conectando";

  const client = window.supabase.createClient(config.supabaseUrl, config.supabaseAnonKey);

  const refreshPresence = async () => {
    await saveCurrentUserOnline(client, user);
    await loadOnlineUsers(client);
  };

  refreshPresence().then(() => {
    presenceStatus.textContent = "Ao vivo";
  });

  presenceHeartbeat = setInterval(refreshPresence, 15000);

  presenceChannel = client
    .channel("conecta-online-users")
    .on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "online_users"
    }, () => {
      loadOnlineUsers(client);
    })
    .subscribe((status) => {
      if (status === "SUBSCRIBED") {
        presenceStatus.textContent = "Ao vivo";
      }
    });

  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) {
      refreshPresence();
    }
  });
}

function createStoryElement(story) {
  const article = document.createElement("article");
  article.className = "story user-story";
  article.dataset.storyId = story.id;
  article.style.setProperty("--story-image", `url("${story.image || defaultStoryImage}")`);
  article.innerHTML = `
    <img src="" alt="">
    <div class="story-content">
      <strong></strong>
      <p></p>
      <span></span>
    </div>
  `;

  article.querySelector("img").src = story.avatar || defaultAvatar;
  article.querySelector("strong").textContent = story.author || "Usuario";
  article.querySelector("p").textContent = story.text || "Novo story";
  article.querySelector("span").textContent = getStoryTimeLabel(story.createdAt);

  return article;
}

function renderStories() {
  document.querySelectorAll(".user-story").forEach((story) => story.remove());

  [...getStories()].reverse().forEach((story) => {
    storiesContainer.querySelector(".create-story").insertAdjacentElement("afterend", createStoryElement(story));
  });
}

function openStoryViewer(storyId) {
  const story = getStories().find((item) => item.id === storyId);
  if (!story || !storyViewer) return;

  storyViewerAvatar.src = story.avatar || defaultAvatar;
  storyViewerAuthor.textContent = story.author || "Usuario";
  storyViewerTime.textContent = getStoryTimeLabel(story.createdAt);
  storyViewerImage.src = story.image || defaultStoryImage;
  storyViewerText.textContent = story.text || "Novo story";
  storyViewer.showModal();
}

function getCommentsLabel(post) {
  const count = (post.comments || []).length;
  return count === 1 ? "1 comentario" : `${count} comentarios`;
}

function createPostElement(post) {
  const article = document.createElement("article");
  article.className = "post user-post";
  article.dataset.postId = post.id;

  article.innerHTML = `
    <header class="post-header">
      <img class="avatar" src="" alt="">
      <div>
        <strong></strong>
        <span></span>
      </div>
      <button class="plain-button delete-post" type="button" aria-label="Apagar publicacao">Apagar</button>
    </header>
    <p></p>
    <div class="post-media-wrap"></div>
    <footer class="post-footer">
      <div class="social-proof"><span class="likes-count"></span><span class="comments-count"></span></div>
      <div class="post-actions">
        <button type="button" class="like-button">Curtir</button>
        <button type="button" class="comment-toggle">Comentar</button>
        <button type="button">Compartilhar</button>
      </div>
      <div class="comments"></div>
      <form class="comment-form" hidden>
        <input type="text" placeholder="Escreva um comentario" aria-label="Escreva um comentario">
        <button type="submit">Enviar</button>
      </form>
    </footer>
  `;

  article.querySelector(".avatar").src = post.avatar || defaultAvatar;
  article.querySelector("strong").textContent = post.author;
  article.querySelector(".post-header span").textContent = `${getPostDateLabel(post.createdAt)} - Publico`;
  article.querySelector("p").textContent = post.text;

  const mediaWrap = article.querySelector(".post-media-wrap");
  if (post.media?.dataUrl) {
    const mediaElement = document.createElement(post.media.type?.startsWith("video/") ? "video" : "img");
    mediaElement.className = "post-media";
    mediaElement.src = post.media.dataUrl;
    if (mediaElement.tagName === "VIDEO") {
      mediaElement.controls = true;
      mediaElement.playsInline = true;
    }
    mediaWrap.appendChild(mediaElement);
  }

  article.querySelector(".likes-count").textContent = `${post.likes} curtidas`;
  article.querySelector(".comments-count").textContent = getCommentsLabel(post);

  const likeButton = article.querySelector(".like-button");
  if (post.liked) {
    likeButton.classList.add("liked");
    likeButton.textContent = "Curtido";
  }

  const comments = article.querySelector(".comments");
  (post.comments || []).forEach((comment) => {
    const item = document.createElement("div");
    item.className = "comment";
    item.innerHTML = "<strong></strong><span></span>";
    item.querySelector("strong").textContent = comment.author;
    item.querySelector("span").textContent = comment.text;
    comments.appendChild(item);
  });

  return article;
}

function renderSavedPosts() {
  document.querySelectorAll(".feed .user-post").forEach((post) => post.remove());

  [...getPosts()].reverse().forEach((post) => {
    composer.insertAdjacentElement("afterend", createPostElement(post));
  });
}

function renderProfilePosts() {
  const user = getSession();
  const posts = getPosts().filter((post) => post.authorEmail === user?.email);
  profilePostsList.innerHTML = "";

  if (!posts.length) {
    const empty = document.createElement("p");
    empty.className = "empty-profile-posts";
    empty.textContent = "Suas publicacoes vao aparecer aqui.";
    profilePostsList.appendChild(empty);
    return;
  }

  posts.forEach((post) => {
    profilePostsList.appendChild(createPostElement(post));
  });
}

function renderGroups() {
  const user = getSession();
  const groups = getGroups().filter((group) => group.ownerEmail === user?.email);
  groupsList.innerHTML = "";

  if (!groups.length) {
    const empty = document.createElement("p");
    empty.className = "empty-profile-posts";
    empty.textContent = "Voce ainda nao criou grupos.";
    groupsList.appendChild(empty);
    return;
  }

  groups.forEach((group) => {
    const card = document.createElement("article");
    card.className = "group-card";
    card.innerHTML = `
      <div class="group-icon"></div>
      <div>
        <h3></h3>
        <span></span>
        <p></p>
      </div>
      <button class="plain-button delete-group" type="button">Apagar</button>
    `;
    card.dataset.groupId = group.id;
    card.querySelector("h3").textContent = group.name;
    card.querySelector("span").textContent = `${group.category} - ${group.members} membro`;
    card.querySelector("p").textContent = group.description;
    groupsList.appendChild(card);
  });
}

function showHomeView() {
  feed.hidden = false;
  profileView.hidden = true;
  groupsView.hidden = true;
  homeButton.classList.add("active");
  groupsButton.classList.remove("active");
}

function showProfileView() {
  const user = getSession();
  if (!user) return;

  updateUserInterface(user);
  renderProfilePosts();
  feed.hidden = true;
  profileView.hidden = false;
  groupsView.hidden = true;
  homeButton.classList.remove("active");
  groupsButton.classList.remove("active");
}

function showGroupsView() {
  renderGroups();
  feed.hidden = true;
  profileView.hidden = true;
  groupsView.hidden = false;
  homeButton.classList.remove("active");
  groupsButton.classList.add("active");
}

function showApp(user) {
  updateUserInterface(user);
  renderStories();
  renderSavedPosts();
  renderNotifications();
  startPresence(user);
  showHomeView();
  notificationPanel.hidden = true;
  authScreen.hidden = true;
  appScreen.hidden = false;
}

function showAuth() {
  appScreen.hidden = true;
  authScreen.hidden = false;
  showAuthTab("login");
}

authTabs.forEach((tab) => {
  tab.addEventListener("click", () => showAuthTab(tab.dataset.authTab));
});

signupAvatar.addEventListener("change", async () => {
  signupAvatarPreview.src = await readImageFile(signupAvatar.files[0]);
});

signupForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const name = document.querySelector("#signupName").value.trim();
  const email = document.querySelector("#signupEmail").value.trim().toLowerCase();
  const password = document.querySelector("#signupPassword").value;
  const users = getUsers();

  if (!name) {
    setAuthMessage("Digite seu nome para criar a conta.");
    return;
  }

  if (!isValidEmail(email)) {
    setAuthMessage("Digite um email valido, exemplo: nome@email.com.");
    return;
  }

  if (password.length < 4) {
    setAuthMessage("A senha precisa ter pelo menos 4 caracteres.");
    return;
  }

  if (users.some((user) => user.email === email)) {
    setAuthMessage("Este email ja tem uma conta. Use o login.");
    return;
  }

  const avatar = await readImageFile(signupAvatar.files[0]);
  const user = { name, email, password, avatar, bio: "" };
  users.push(user);
  saveUsers(users);
  setSession(user);
  signupForm.reset();
  addNotification(`Bem-vindo ao Conecta, ${name}!`);
  showApp(user);
});

loginForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const email = document.querySelector("#loginEmail").value.trim().toLowerCase();
  const password = document.querySelector("#loginPassword").value;
  const user = getUsers().find((item) => item.email === email && item.password === password);

  if (!isValidEmail(email)) {
    setAuthMessage("Digite um email valido, exemplo: nome@email.com.");
    return;
  }

  if (!password) {
    setAuthMessage("Digite sua senha para entrar.");
    return;
  }

  if (!user) {
    setAuthMessage("Email ou senha incorretos.");
    return;
  }

  setSession(user);
  loginForm.reset();
  renderNotifications();
  showApp(user);
});

logoutButton.addEventListener("click", () => {
  stopPresence();
  localStorage.removeItem(storageKeys.session);
  notificationPanel.hidden = true;
  showAuth();
});

changePhotoButton.addEventListener("click", () => {
  changePhotoInput.click();
});

changePhotoInput.addEventListener("change", async () => {
  const file = changePhotoInput.files[0];
  const session = getSession();
  if (!file || !session) return;

  const avatar = await readImageFile(file);
  const users = getUsers().map((user) => {
    if (user.email !== session.email) return user;
    return { ...user, avatar };
  });
  const posts = getPosts().map((post) => {
    if (post.authorEmail !== session.email) return post;
    return { ...post, avatar };
  });
  const stories = getStories().map((story) => {
    if (story.authorEmail !== session.email) return story;
    return { ...story, avatar };
  });
  const updatedSession = { ...session, avatar };

  saveUsers(users);
  savePosts(posts);
  saveStories(stories);
  setSession(updatedSession);
  updateUserInterface(updatedSession);
  renderStories();
  renderSavedPosts();
  renderProfilePosts();
  addNotification("Sua foto de perfil foi atualizada.");
  changePhotoInput.value = "";
});

notificationButton.addEventListener("click", () => {
  notificationPanel.hidden = !notificationPanel.hidden;
  if (!notificationPanel.hidden) {
    markNotificationsRead();
  }
});

clearNotificationsButton.addEventListener("click", () => {
  saveNotifications([]);
  renderNotifications();
});

homeButton.addEventListener("click", showHomeView);
groupsButton.addEventListener("click", showGroupsView);
topGroupsButton.addEventListener("click", showGroupsView);
sideGroupsButton.addEventListener("click", showGroupsView);
topProfileButton.addEventListener("click", showProfileView);
sideProfileButton.addEventListener("click", showProfileView);

editBioButton.addEventListener("click", () => {
  const user = getSession();
  bioText.value = user?.bio || "";
  bioDialog.showModal();
  bioText.focus();
});

saveBioButton.addEventListener("click", () => {
  const session = getSession();
  if (!session) return;

  const bio = bioText.value.trim();
  const users = getUsers().map((user) => {
    if (user.email !== session.email) return user;
    return { ...user, bio };
  });
  const updatedSession = { ...session, bio };

  saveUsers(users);
  setSession(updatedSession);
  updateUserInterface(updatedSession);
  renderProfilePosts();
  addNotification("Sua bio foi atualizada.");
});

openGroupDialog.addEventListener("click", () => {
  groupDialog.showModal();
  groupName.focus();
});

groupForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const user = getSession();
  if (!user) return;

  const group = {
    id: crypto.randomUUID(),
    ownerEmail: user.email,
    name: groupName.value.trim(),
    category: groupCategory.value,
    description: groupDescription.value.trim(),
    members: 1,
    createdAt: new Date().toISOString()
  };

  saveGroups([group, ...getGroups()]);
  groupForm.reset();
  groupDialog.close();
  renderGroups();
  addNotification(`Voce criou o grupo ${group.name}.`);
});

btnPhoto?.addEventListener("click", () => {
  postMediaInput?.click();
});

postMediaInput?.addEventListener("change", async () => {
  const file = postMediaInput.files[0];
  if (!file) return;

  selectedPostMedia = await readMediaFile(file);
  postDialog.showModal();
  postText.focus();
  addNotification("Arquivo selecionado para a proxima publicacao.");
});

btnLive?.addEventListener("click", () => {
  addNotification("Recurso de video ao vivo sera ativado em uma proxima etapa.");
  alert("Video ao vivo sera ativado em breve.");
});

btnMood?.addEventListener("click", () => {
  const mood = prompt("Como voce esta se sentindo agora?", "feliz");
  if (!mood) return;
  postDialog.showModal();
  postText.value = postText.value ? `${postText.value} - me sentindo ${mood}` : `Estou me sentindo ${mood}`;
  postText.focus();
});

openComposer?.addEventListener("click", () => {
  postDialog.showModal();
  postText.focus();
});

openStoryDialog?.addEventListener("click", () => {
  const user = getSession();

  if (!user) {
    showAuth();
    return;
  }

  storyForm.reset();
  storyPreview.src = defaultStoryImage;
  storyDialog.showModal();
  storyText.focus();
});

storyImage?.addEventListener("change", async () => {
  storyPreview.src = await readStoryImageFile(storyImage.files[0]);
});

publishStory?.addEventListener("click", async (event) => {
  const user = getSession();

  if (!user) {
    event.preventDefault();
    showAuth();
    return;
  }

  const text = storyText.value.trim();
  const imageFile = storyImage.files[0];

  if (!text && !imageFile) {
    event.preventDefault();
    storyText.focus();
    return;
  }

  const image = await readStoryImageFile(imageFile);

  const story = {
    id: crypto.randomUUID(),
    author: user.name,
    authorEmail: user.email,
    avatar: user.avatar || defaultAvatar,
    image,
    text: text || "Novo story",
    createdAt: new Date().toISOString()
  };

  saveStories([story, ...getStories()].slice(0, 12));
  renderStories();
  addNotification("Seu story foi publicado.");
  storyForm.reset();
  storyPreview.src = defaultStoryImage;
});

publishPost?.addEventListener("click", (event) => {
  const text = postText.value.trim();
  const user = getSession();

  if (!user) {
    event.preventDefault();
    showAuth();
    return;
  }

  if (!text) {
    event.preventDefault();
    postText.focus();
    return;
  }

  const post = {
    id: crypto.randomUUID(),
    author: user?.name || "Usuario",
    authorEmail: user?.email || "",
    avatar: user?.avatar || defaultAvatar,
    text,
    createdAt: new Date().toISOString(),
    media: selectedPostMedia,
    likes: 0,
    liked: false,
    comments: []
  };
  const posts = [post, ...getPosts()];
  savePosts(posts);
  renderSavedPosts();
  renderProfilePosts();
  addNotification("Sua publicacao foi criada.");
  selectedPostMedia = null;
  if (postMediaInput) postMediaInput.value = "";
  postText.value = "";
});

document.addEventListener("click", (event) => {
  const storyElement = event.target.closest(".user-story");
  if (storyElement) {
    openStoryViewer(storyElement.dataset.storyId);
    return;
  }

  const postElement = event.target.closest(".user-post");

  if (event.target.closest(".like-button") && postElement) {
    const posts = getPosts();
    const post = posts.find((item) => item.id === postElement.dataset.postId);
    if (!post) return;

    post.liked = !post.liked;
    post.likes += post.liked ? 1 : -1;
    savePosts(posts);
    renderSavedPosts();
    renderProfilePosts();
    if (post.liked) {
      addNotification(`Voce curtiu a publicacao de ${post.author}.`);
    }
    return;
  }

  const staticLikeButton = event.target.closest(".like-button");
  if (staticLikeButton) {
    staticLikeButton.classList.toggle("liked");
    staticLikeButton.textContent = staticLikeButton.classList.contains("liked") ? "Curtido" : "Curtir";
    if (staticLikeButton.classList.contains("liked")) {
      addNotification("Voce curtiu uma publicacao do feed.");
    }
    return;
  }

  if (event.target.closest(".comment-toggle") && postElement) {
    const form = postElement.querySelector(".comment-form");
    form.hidden = !form.hidden;
    if (!form.hidden) {
      form.querySelector("input").focus();
    }
    return;
  }

  if (event.target.closest(".delete-post") && postElement) {
    const posts = getPosts().filter((post) => post.id !== postElement.dataset.postId);
    savePosts(posts);
    renderSavedPosts();
    renderProfilePosts();
  }

  const groupElement = event.target.closest(".group-card");
  if (event.target.closest(".delete-group") && groupElement) {
    const groups = getGroups().filter((group) => group.id !== groupElement.dataset.groupId);
    saveGroups(groups);
    renderGroups();
    addNotification("Grupo apagado.");
  }
});

document.addEventListener("keydown", (event) => {
  if (event.key !== "Enter" || !event.target.matches(".comment-form input")) return;

  event.preventDefault();
  event.target.closest(".comment-form").requestSubmit();
});

document.addEventListener("submit", (event) => {
  const form = event.target.closest(".comment-form");
  if (!form) return;

  event.preventDefault();
  const postElement = form.closest(".user-post");
  const input = form.querySelector("input");
  const text = input.value.trim();
  const user = getSession();

  if (!text) return;

  const posts = getPosts();
  const post = posts.find((item) => item.id === postElement.dataset.postId);
  if (!post) return;

  post.comments.push({
    author: user?.name || "Usuario",
    text
  });

  savePosts(posts);
  renderSavedPosts();
  renderProfilePosts();
  addNotification(`Voce comentou na publicacao de ${post.author}.`);
});

closeStoryViewer?.addEventListener("click", () => storyViewer?.close());

storyViewer?.addEventListener("click", (event) => {
  if (event.target === storyViewer) {
    storyViewer.close();
  }
});

const activeSession = getSession();

if (activeSession) {
  showApp(activeSession);
} else {
  showAuth();
}


document.addEventListener('DOMContentLoaded',()=>{
 const fab=document.getElementById('fabCompose');
 const composer=document.getElementById('openComposer');
 if(fab&&composer){fab.addEventListener('click',()=>composer.click());}
});


// ===== Conecta+ 3.1 - convite premium =====
(function(){
  const inviteDialog = document.getElementById('inviteDialog');
  const inviteButtons = [
    document.getElementById('sendInviteButton'),
    document.querySelector('.invite-rail'),
    document.getElementById('copyInviteCode')
  ].filter(Boolean);
  const code = 'MARCOS75';
  const inviteLink = `${location.origin}${location.pathname}?convite=${code}`;
  const inviteText = `💜 Marcos convidou você para fazer parte do Conecta+! Entre com o código ${code}: ${inviteLink}`;
  function openInvite(){ if(inviteDialog?.showModal) inviteDialog.showModal(); else alert(inviteText); }
  async function copyInvite(){
    try { await navigator.clipboard.writeText(inviteText); addNotification?.('Convite Conecta+ copiado com sucesso.'); alert('Convite copiado!'); }
    catch { prompt('Copie seu convite:', inviteText); }
  }
  inviteButtons.forEach(btn => btn.addEventListener('click', (e)=>{ e.preventDefault(); openInvite(); }));
  document.getElementById('inviteWhatsapp')?.addEventListener('click',()=> window.open(`https://wa.me/?text=${encodeURIComponent(inviteText)}`,'_blank'));
  document.getElementById('inviteTelegram')?.addEventListener('click',()=> window.open(`https://t.me/share/url?url=${encodeURIComponent(inviteLink)}&text=${encodeURIComponent(inviteText)}`,'_blank'));
  document.getElementById('inviteEmail')?.addEventListener('click',()=> { location.href = `mailto:?subject=${encodeURIComponent('Convite para o Conecta+')}&body=${encodeURIComponent(inviteText)}`; });
  document.getElementById('inviteCopy')?.addEventListener('click', copyInvite);
  document.getElementById('achievementButton')?.addEventListener('click',()=> alert('Conquistas em breve: Embaixador, Criador, VIP e Premium.'));
})();
