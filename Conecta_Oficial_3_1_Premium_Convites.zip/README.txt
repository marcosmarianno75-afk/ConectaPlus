CONECTA 2.0 - Versao oficial organizada

Arquivos principais:
- index.html
- script.js
- styles.css
- config.js

Melhorias aplicadas:
- Publicacoes novas aparecem no topo do feed.
- Stories publicados agora sao clicaveis e abrem em visualizador.
- Botao Foto/video abre seletor de arquivo e permite publicar imagem/video junto com texto.
- Botao Sentimento preenche o composer com sentimento.
- Botao Video ao vivo responde com aviso de recurso futuro.
- Interface ajustada para identidade lilas/roxa moderna.

Como subir:
1. Envie este ZIP no Netlify Drop.
2. Abra o site em aba anonima para evitar cache antigo.
3. Use somente esta versao como base oficial.


Atualizacao v2.1: logo oficial com simbolo de mais (+), representando conexao, crescimento e novas possibilidades.
