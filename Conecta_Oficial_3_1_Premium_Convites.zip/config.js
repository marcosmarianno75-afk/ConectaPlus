window.conectaConfig = {
  supabaseUrl: "https://cdwbkcnnziyziozlkpyj.supabase.co",
  supabaseAnonKey: "sb_publishable_AgZvRWpkd-WkZ7AiOORVow_xizypOYG"
};